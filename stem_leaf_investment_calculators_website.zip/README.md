# Stem & Leaf Financial Services — Investment Calculator Website

A zero-dependency, responsive static website containing:
- SIP Calculator
- Advance / Step-up SIP
- Lumpsum Calculator
- SIP + Lumpsum
- Compare SIP
- SWP
- STP
- Goal Planner

## Run locally
Open `index.html` in a browser, or serve the folder with any static web server.

## Free publishing
This is a static site and can be published free on GitHub Pages, Cloudflare Pages, or Netlify's free tier.

## WhatsApp image sharing
The site generates a PNG result image. On supported mobile browsers it uses the native share sheet, where WhatsApp can be selected. A browser cannot silently attach an image to a specific WhatsApp recipient without WhatsApp/API permissions, so the fallback opens the fixed WhatsApp chat and provides the image for sharing.

Fixed WhatsApp destination configured in the code:
+91 91463 63727
